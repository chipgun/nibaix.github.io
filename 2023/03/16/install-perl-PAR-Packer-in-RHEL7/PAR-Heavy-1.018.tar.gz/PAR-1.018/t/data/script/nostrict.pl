#!/usr/bin/perl

${'a'} = "No Strict!\n";
print $a;
