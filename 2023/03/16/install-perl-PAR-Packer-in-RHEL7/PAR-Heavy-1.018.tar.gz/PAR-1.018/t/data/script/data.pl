#!/usr/bin/perl

use Data;

Data::data();
print <DATA>;

__DATA__
Data reflection
