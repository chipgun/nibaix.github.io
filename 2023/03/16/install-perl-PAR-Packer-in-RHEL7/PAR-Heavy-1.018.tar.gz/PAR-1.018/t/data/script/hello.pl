#!/usr/bin/perl

use Hello;

Hello::hello();
print "Goodbye, world!\n";
