package Hello;

use strict;
sub hello {
    print "Hello, world!\n";
}

1;
