package Data;

use strict;
sub data {
    print <DATA>;
}

1;
__DATA__
Data section
